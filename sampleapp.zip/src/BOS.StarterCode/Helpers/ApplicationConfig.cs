﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOS.StarterCode.Helpers
{
    public static class ApplicationConfig
    {
        public static string Name { get; set; }
        public static string URL { get; set; }
        public static string Logo { get; set; }

    }
}
